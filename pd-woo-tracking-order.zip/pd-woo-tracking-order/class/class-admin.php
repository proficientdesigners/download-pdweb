<?php

/**
 * @link https://proficientdesigners.com/
 *
 * @package Proficient Designers Plugin
 * @subpackage pd Woo Tracking Order
 * @since 1.0.0
 * @version 1.0.0
 */

if ( ! class_exists('pdWooTrackingOrderAdmin') ) {
	
	class pdWooTrackingOrderAdmin {

		function __construct( $plugin_uri ) {

			if ( ! current_user_can( 'activate_plugins' ) )
				return;

			$this->plugin_uri = $plugin_uri;

			add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ], 10, 1 );
			add_action( 'add_meta_boxes', [ $this, 'meta_boxes' ], 10, 2 );
			add_action( 'admin_menu', [ $this, 'options_page' ] );
			add_action( 'admin_init', [ $this, 'admin_settings_page_init' ] );
			add_action( 'save_post', [ $this, 'save_order_tracking_details'], 10, 2 );
		}

		public function admin_path( $file ) {

			return plugin_dir_path( dirname(__FILE__) ) . 'admin/' . $file;	
		}

		public function admin_url( $file ) {

			return plugin_dir_url( dirname(__FILE__) ) . 'admin/' . $file;	
		}

		public function enqueue_admin() {

			wp_enqueue_style( 'pd-Woo-Tracking-Order', $this->admin_url('admin-ui.css'), [], false, 'all' );
			wp_enqueue_script( 'pd-Woo-Tracking-Order', $this->admin_url('admin.js'), array('jquery'), '1.0', false);
		}

		public function meta_boxes() {

			add_meta_box( 'pd-Woo-Tracking-Order-Meta-Box', 'pd Woo Track Order', [ $this, 'meta_boxes_cb' ], 'shop_order', 'side', 'high' );
		}

		public function meta_boxes_cb( $post ) {

			require $this->admin_path( 'metabox.php' );
		}

		public function options_page() {

			$icon_url = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAyMS4wLjIsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiDQoJIHdpZHRoPSI2MDBweCIgaGVpZ2h0PSI2MDBweCIgdmlld0JveD0iMCAwIDYwMCA2MDAiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDYwMCA2MDA7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+DQoJLnN0MHtmaWxsOiNGRkZGRkY7fQ0KCS5zdDF7ZmlsbDojMTQxNDE0O30NCgkuc3Qye2ZpbGw6IzZEOUYyMTt9DQo8L3N0eWxlPg0KPGNpcmNsZSBjbGFzcz0ic3QwIiBjeD0iMzAxIiBjeT0iMzAxIiByPSIyOTQiLz4NCjxnPg0KCTxwYXRoIGNsYXNzPSJzdDEiIGQ9Ik01MTIuNiwxODQuM2MtNC44LTI2LjItMTYuMS00OS4yLTM0LjItNjguOWMtMjUuNS0yNy44LTU3LjEtNDIuNy05NC42LTQ1LjZjLTExLjQtMC45LTIyLjctMC4yLTMzLjksMS45DQoJCWMtMjcuOSw1LjEtNTIuMiwxNy41LTcyLjYsMzcuMmMtOS41LDkuMi0xOC44LDE4LjctMjguMSwyOC4xYy0yLjUsMi42LTUuNCwzLjctOSwzLjdjLTkuNS0wLjEtMTkuMSwwLTI4LjcsMGMtOC4xLDAtMTYuMiwwLTI0LjMsMA0KCQljLTIuOSwwLTUuNywwLjItOC41LDAuNWMtMTQuNSwxLjgtMjYuOSw4LjEtMzcuMSwxOC41Yy0xMS44LDEyLjItMTcuNiwyNy0xNy43LDQzLjhjLTAuMSwyOC4yLTAuMSw1Ni41LDAsODQuNw0KCQljMCwzLjItMSw1LjktMy4xLDguNGMtNS42LDYuNC0xMC43LDEzLjItMTUuMiwyMC41Yy0xMi45LDIwLjUtMTkuOCw0Mi45LTIwLjYsNjcuMWMtMC4zLDcuNywwLjIsMTUuNSwxLjEsMjMuMg0KCQljMS4zLDEwLjUsMy41LDIwLjcsNywzMC43YzcuMSwyMC41LDE4LjksMzcuOSwzNC40LDUzYzMzLjUsMzIuNSw3OC45LDQ0LjcsMTIwLjgsMzcuNWMyOS40LTUsNTQuNy0xOC4xLDc1LjktMzkuMQ0KCQljOC45LTguOCwxNy44LTE3LjcsMjYuNi0yNi42YzIuNi0yLjYsNS41LTMuOCw5LjEtMy44YzE3LjcsMC4xLDM1LjQsMCw1My4xLDBjOC4yLDAsMTYuMS0xLjUsMjMuNi00LjZjMjMtOS41LDM4LTMwLjcsMzguOS01NS41DQoJCWMwLjMtOCwwLjItMTYsMC4yLTI0YzAtMTAuMSwwLTIwLjIsMC0zMC4zYzAtMTEuMi0wLjEtMjIuMy0wLjEtMzMuNWMwLTIuOCwwLjktNS4zLDIuOS03LjRjMC41LTAuNSwxLTEuMSwxLjUtMS43DQoJCWMyMS44LTI1LDMzLjEtNTQuMiwzNC42LTg3LjNDNTE1LjQsMjA0LjUsNTE0LjQsMTk0LjQsNTEyLjYsMTg0LjN6IE00NjEuMiwyMzdjLTQuMywxMy41LTExLjcsMjUuMi0yMS40LDM1LjUNCgkJYy0xLjEsMS4xLTIuMSwyLjMtMy4yLDMuM2MtMC44LDAuNy0xLjEsMS41LTEuMSwyLjZjMC4xLDQsMCw4LjEsMCwxMi4xYzAsMzQuNiwwLDY5LjIsMCwxMDMuN2MwLDMuOC0wLjUsNy41LTIsMTENCgkJYy0zLjQsNy41LTkuMywxMS42LTE3LjMsMTIuOWMtMS45LDAuMy0zLjcsMC4zLTUuNiwwLjNjLTI2LjQsMC01Mi45LDAtNzkuMywwYy0xLjUsMC0yLjksMC00LjQtMC4xYy0xLjMtMC4xLTIuMywwLjMtMy4zLDEuMw0KCQljLTYsNi4yLTEyLjIsMTIuMy0xOC4zLDE4LjRjLTUuNyw1LjctMTEuNCwxMS41LTE3LjIsMTcuMWMtMTMuNCwxMi45LTI5LjEsMjEuMi00Ny41LDI0LjJjLTM4LjIsNi4zLTc1LjUtMTEuMS05NC4zLTQ0LjQNCgkJYy01LjktMTAuNS05LjQtMjEuOC0xMS0zMy44Yy0xLjctMTIuNy0wLjktMjUuMiwyLjktMzcuNGMzLjgtMTIuMiwxMC4xLTIzLDE4LjQtMzIuOGMyLTIuMyw0LjEtNC42LDYuMy02LjhjMS0xLDEuNC0xLjksMS40LTMuMw0KCQljMC0yNS42LDAtNTEuMiwwLTc2LjhjMC0xMS42LDAtMjMuMSwwLTM0LjdjMC0yLjYtMC4yLTUuMiwwLTcuN2MwLjktMTAuMiw4LjQtMTguNSwxOC41LTIwLjJjMy4xLTAuNSw2LjQtMC41LDkuNi0wLjUNCgkJYzEyLjUtMC4xLDI1LDAsMzcuNCwwYzAsMCwwLDAsMCwwLjFjMTQuNCwwLDI4LjcsMCw0My4xLDBjMS41LDAsMi42LTAuNCwzLjctMS41YzExLjktMTEuOSwyMy42LTIzLjksMzUuNy0zNS42DQoJCWMxMy44LTEzLjUsMzAuNC0yMS40LDQ5LjUtMjQuMWMzOS42LTUuNyw3Ni42LDE1LjEsOTMuNSw0OC4yYzUuMSw5LjksOCwyMC40LDkuMywzMS41QzQ2Ni4xLDIxMi41LDQ2NS4xLDIyNC45LDQ2MS4yLDIzN3oiLz4NCgk8cGF0aCBjbGFzcz0ic3QyIiBkPSJNNDA0LjYsMzg1LjVjMC0zNy4yLDAtNzQuNCwwLTExMS43YzAtMzcuMSwwLTc0LjIsMC0xMTEuM2MwLTAuNywwLTEuNCwwLTIuMWMtMC4xLTIuMy0wLjYtMi45LTIuOS0yLjkNCgkJYy0xMi44LDAtMjUuNywwLTM4LjUsMGMtMi4xLDAtMy4xLDAuOS0zLjIsM2MtMC4xLDAuNiwwLDEuMywwLDEuOWMwLDE2LjcsMCwzMy4zLDAsNTBjMCwwLjgsMCwxLjUtMC4xLDIuMw0KCQljLTAuMiwxLjUtMS4xLDEuOS0yLjMsMS4xYy0wLjgtMC41LTEuNC0xLjEtMi4xLTEuOGMtMi43LTIuNi01LjgtNC40LTkuNC01LjNjLTEwLjctMi41LTIwLTAuMS0yNy44LDcuNw0KCQljLTMuOSwzLjktNi42LDguNi04LjUsMTMuOGMtMy44LDkuOC01LjMsMjAuMS01LjQsMzAuNWMtMC4yLDI0LjctMC4xLDQ5LjQsMCw3NGMwLDguMSwwLjgsMTYuMSwyLjUsMjQuMQ0KCQljMS4zLDYuNCwzLjMsMTIuNSw2LjcsMTguMWM0LjYsNy41LDExLDEyLjQsMTkuOSwxMy4yYzcuMywwLjcsMTQuMS0wLjcsMjAuMy00LjljMC45LTAuNiwxLjgtMS4zLDIuOC0xLjljMS40LTAuOCwxLjktMC44LDIuOCwwLjYNCgkJYzAuOSwxLjQsMS44LDIuOCwyLjYsNC4zYzAuOSwxLjUsMiwyLjIsMy45LDIuMmMxMS42LTAuMSwyMy4zLDAsMzQuOSwwYzAuNSwwLDEsMCwxLjUsMGMxLjQtMC4xLDIuMy0xLDIuNC0yLjQNCgkJQzQwNC42LDM4Ny4yLDQwNC42LDM4Ni4zLDQwNC42LDM4NS41eiBNMzU3LjcsMzQyLjRjLTAuNiwwLjYtMS4zLDEuMS0yLDEuNGMtMi41LDEuMS00LjktMC4xLTUuNS0yLjdjLTAuMy0xLjQtMC40LTIuOS0wLjQtNC40DQoJCWMwLTEyLjIsMC0yNC40LDAtMzYuNmMwLTEyLjMsMC0yNC41LDAtMzYuOGMwLTEuNCwwLjEtMi44LDAuNC00LjFjMC45LTMuOCw0LjUtNC45LDcuMy0yLjJjMS41LDEuNCwyLjMsMy4zLDIuNSw1LjQNCgkJYzAuMSwwLjYsMC4xLDEuMywwLjEsMS45YzAsMjMuOSwwLDQ3LjgsMCw3MS43QzM2MCwzMzguNSwzNTkuNSwzNDAuNywzNTcuNywzNDIuNHoiLz4NCgk8cGF0aCBjbGFzcz0ic3QyIiBkPSJNMjk1LjQsMjczLjFjMC02LjUtMC4yLTEzLTAuNS0xOS40Yy0wLjQtNy4zLTEuNi0xNC40LTMuOC0yMS4zYy0xLjctNS41LTQuMS0xMC43LTcuOC0xNS4yDQoJCWMtMy40LTQuMS03LjYtNy0xMi43LTguM2MtOC4yLTIuMS0xNi0wLjktMjMuNCwzLjJjLTEuMSwwLjYtMi4xLDEuNC0zLjEsMi4yYy0yLjMsMS43LTIuOSwxLjYtNC40LTAuOGMtMC44LTEuMi0xLjUtMi40LTIuMS0zLjYNCgkJYy0wLjgtMS41LTEuOC0yLTMuNS0yYy0xMS43LDAuMS0yMy40LDAtMzUuMSwwYy0wLjQsMC0wLjgsMC0xLjMsMGMtMS41LDAuMi0yLjQsMS4xLTIuNSwyLjZjLTAuMSwwLjgsMCwxLjcsMCwyLjUNCgkJYzAsMzYuMywwLDcyLjcsMCwxMDljMCwzNi43LDAsNzMuMywwLDExMGMwLDMuOCwwLjksNC4yLDQuMiw0LjJjMTIuMS0wLjEsMjQuMSwwLDM2LjIsMGMwLjUsMCwxLDAsMS41LDBjMS43LTAuMSwyLjUtMSwyLjctMi42DQoJCWMwLjEtMC43LDAtMS40LDAtMi4xYzAtMTUsMC0zMCwwLTQ1YzAtMC42LTAuMS0xLjMsMC0xLjljMC4yLTAuOCwwLjQtMiwxLTIuM2MwLjktMC42LDEuNiwwLjUsMi4yLDEuMWM3LjUsNywxNi4zLDguNywyNiw2DQoJCWM3LjctMi4xLDEzLjItNy4yLDE3LjMtMTMuOWM0LjgtNy45LDYuOS0xNi43LDguMi0yNS43YzAuOS02LjgsMS0xMy43LDEtMjAuN0MyOTUuNCwzMTAuMywyOTUuNSwyOTEuNywyOTUuNCwyNzMuMXogTTI0OS45LDMzNS44DQoJCWMwLDEuMy0wLjEsMi43LTAuNSwzLjljLTEsMy0zLjksMy45LTYuNiwyYy0yLjItMS41LTIuOS0zLjktMy4xLTYuM2MtMC4xLTAuNSwwLTEuMSwwLTEuN2MwLTIzLjgsMC00Ny43LDAtNzEuNQ0KCQljMC0yLjMsMC41LTQuNCwyLTYuMmMxLTEuMiwyLjMtMS44LDMuOC0xLjljMS45LTAuMiwzLjUsMC44LDQuMSwyLjZjMC4zLDEsMC41LDIuMiwwLjUsMy4zYzAsMTIuOCwwLDI1LjUsMCwzOC4zDQoJCUMyNDkuOSwzMTAuNywyNTAsMzIzLjMsMjQ5LjksMzM1Ljh6Ii8+DQo8L2c+DQo8L3N2Zz4=";

			add_menu_page( 'Woocommerce Tracking Order', 'Tracking Order', 'manage_options', $this->plugin_uri, [$this, 'options_page_cb'], $icon_url );
		}

		public function options_page_cb() {

			$order = wc_get_order( $order_id );

			require $this->admin_path( 'settings.php' );
		}

		public function all_fields() {

			return [
				'pd_woo_track_order_carrier_name' => 'Carrier Name',
				'pd_woo_track_order_message' => 'Track Order Message'
			];
		}

		public function admin_settings_page_init() {

			add_settings_section( 'pd_Woo_Tracking_Order_Section', 'Woocommerce Tracking Order', [$this, 'admin_settings_page_section_cb'], $this->plugin_uri );

			foreach ($this->all_fields() as $key => $value) {

				add_settings_field( $key, $value, function() use ($key, $value) {

					switch ($key) {
						case 'pd_woo_track_order_carrier_name':
						echo '<input type="text" name="'.$key.'" value="'. @get_option( $key, true ) .'">';
						echo "<small><i><b>Note:</b> You can set the default carrier name for all your shipments in common or you can change it for each order.</small>";
						break;

						case 'pd_woo_track_order_message':
						echo '<textarea rows="7" name="'.$key.'">'. @get_option( $key, true ) .'</textarea>';
						echo '<small><i><b>Note:</b> You can edit this text as you wish, but to show the carrier name, pickup time etc, use this placeholders as it is along with curley braces </i><code>{carrier_name}</code>, <code>{pickup_date}</code>, <code>{tracking_id}</code></small>';
						break;
					}

				}, $this->plugin_uri, 'pd_Woo_Tracking_Order_Section');

				register_setting( $this->plugin_uri, $key );
			}
		}

		public function admin_settings_page_section_cb() {

			echo "<p>Here you can set the default settings of your order tracking system.</p>";
		}

		public function save_order_tracking_details($post_id, $post) {

			/* Verify the nonce before proceeding. */
			if ( !isset( $_POST['pd_woo_tracking_details'] ) )
				return $post_id;

			if ( !wp_verify_nonce( $_POST['pd_woo_tracking_details'], 'pd_woo_tracking_details_nonce' ) )
				return;

			if ( get_post_type( $post ) !== 'shop_order' )
				return;

			$fields = [
				'pd_woo_track_order_status' 				=> sanitize_text_field( $_POST['pd_woo_track_order_status'] ),
				'pd_woo_track_order_carrier_name' 			=> sanitize_text_field( $_POST['pd_woo_track_order_carrier_name'] ),
				'pd_woo_track_order_carrier_pickup_date' 	=> sanitize_text_field( $_POST['pd_woo_track_order_carrier_pickup_date'] ),
				'pd_woo_track_order_tracking_id' 			=> sanitize_text_field( $_POST['pd_woo_track_order_tracking_id'] )
			];

			update_post_meta( $post_id, '_pd_woo_track_order_meta', $fields );

		}
	}
}
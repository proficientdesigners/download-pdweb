<?php

/**
 * @link https://proficientdesigners.com/
 *
 * @package Proficient Designers Plugin
 * @subpackage pd Woo Tracking Order
 * @since 1.0.0
 * @version 1.0.0
 */

if ( ! class_exists('pdWooTrackingOrderFront') ) {
	
	class pdWooTrackingOrderFront {

		function __construct() {

			add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_front_end' ], 10, 1 );
			add_action( 'woocommerce_view_order', [ $this, 'html' ], 10, 1 );
			add_action( 'woocommerce_thankyou', [ $this, 'html' ], 10, 1 );
		}

		public function public_path( $file ) {

			return plugin_dir_path( dirname(__FILE__) ) . 'front/' . $file;	
		}

		public function public_url( $file ) {

			return plugin_dir_url( dirname(__FILE__) ) . 'front/' . $file;	
		}

		public function enqueue_front_end() {

			wp_enqueue_style( 'pd-Woo-Tracking-Order', $this->public_url('front-ui.css'), [], false, 'all' );
		}

		public function html( $order_id ) {

			if ( ! current_user_can( 'activate_plugins' ) )
				return;

			$order = wc_get_order( $order_id );

			require $this->public_path( 'front-end-ui.php' );
		}
	}
}
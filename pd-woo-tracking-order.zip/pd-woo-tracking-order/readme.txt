=== pd Woo Tracking Order ===
Contributors: Proficient Designers
Tags: Woocommerce, Tracking, Order Tracking, Woocommerce Order Tracking
Requires at least: 4.0
Tested up to: 5.3.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

You can set the custom Woocommerce Order Status and can able to add a Tracking ID of your carrier service provider with a nice front end user interface of tracking system.

== Description ==
You can set the custom Woocommerce Order Status and can able to add a Tracking ID of your carrier service provider with a nice front end user interface of tracking system.

**5 Order Tracking Status:**

1. Order Placed
1. Order Confirmed
1. Order Packed
1. Order Shipped
1. Order Delivered

**Features Included:**

* In settings page a default carrier name & track order message can be added.
* For each order the default settings can be edited.
* For more documentation and demo videos, please visit [proficientdesigners.in](https://proficientdesigners.in/creations/pd-woo-tracking-order/)

== Installation ==
1. Upload `pd-woo-tracking-order` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Can i add default settings ? =
Yes, you can add default settings from Tracking Order settings page.

= Can i change default settings from inside each order ? =
Yes, there is an option where you can change default settings from each order page.

= Can i hide the tracking order status from store front ? =
Ofcourse you can hide it by deactivating the plugin. Simple!. But all your settings remains saved.

== Screenshots ==

1. Admin backend settings
2. Woocommerce order page
3. Store front order placed page
4. Store front order view page
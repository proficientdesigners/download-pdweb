jQuery(document).ready(function($) {
	$("#pdWooTrcOrdrDatePicker").datepicker({
		dateFormat : "dd-mm-yy"
	});
});